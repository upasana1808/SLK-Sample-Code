package com.example.LoginDemo.DAO;

public interface CustomerDAO {
	public int loginValidation(String username,String password);
}
