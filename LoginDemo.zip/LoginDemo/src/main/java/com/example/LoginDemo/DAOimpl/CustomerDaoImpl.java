package com.example.LoginDemo.DAOimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.LoginDemo.DAO.CustomerDAO;
import com.example.LoginDemo.model.Customer;
import com.example.LoginDemo.util.DButil;

@Repository
public class CustomerDaoImpl implements CustomerDAO{
	static List<Customer> list1=new ArrayList();
	Connection connection;
	
	public CustomerDaoImpl() {
		connection = DButil.getConnection();
		System.out.println("connection" + connection);
	}	
	
	public List<Customer> viewAllCustomer(){
		//List<Customer> customer = new ArrayList<Customer>();		
		System.out.println("Inside viewAll customer");
		try {
			
			System.out.println("Inside try");
			PreparedStatement stmt = connection.prepareStatement("select * from customer");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				Customer cust=new Customer();
				System.out.println("Inside while");
				cust.setId(rs.getInt(1));
				cust.setUsername(rs.getString(2));
				cust.setPassword(rs.getString(3));
				cust.setEmail(rs.getString(4));
				cust.setPhone(rs.getLong(5));
				System.out.println("Inside while-2");
				list1.add(cust);
				System.out.println(list1);				
			}
			}catch(Exception e) {}
		return list1;
	}

	
	
	public int loginValidation(String username,String password) {
		viewAllCustomer();
		int flag=0;
		System.out.println(list1);
		for (Customer c:list1) {
			System.out.println("Customer data----"+c);
			if (c.getUsername().equals(username)  && c.getPassword().equals(password)) {
				flag=1;							
				//return flag;
			}
		}
		System.out.println("flag"+flag);
		return flag;
	}
}
