package com.example.LoginDemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.LoginDemo.DAO.CustomerDAO;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CustomerController {
	@Autowired
	private CustomerDAO customerDAO;
	
	@GetMapping("/Customer/{username}/{password}")
	public ResponseEntity getCustomerLogin(@PathVariable("username") String username,@PathVariable("password") String password) {		
		int flag=customerDAO.loginValidation(username,password);			
		if (flag == 0) {
			return new ResponseEntity("No Customer found for ID " + username, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(flag, HttpStatus.OK);
	}
	

}
